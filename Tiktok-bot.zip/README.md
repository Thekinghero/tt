<h1 align="center">💎TMB {TikTok Mass Botting}</h1>

<p align='center'>
  <b>Star ⭐ if you want more</b><br>
</p>

Join here if you need help ! https://discord.gg/069
discord.gg/tiktokshares
PATCHED EVENTUALLY JOIN DISCORD 4 HELP
ITS SLOW FOR NOW BUT IT WILL BE FASTER SOON. BETTER SLOW THAN PATCHED
WERE FIXIING IT
## Features
```js
  * View botting
  * Share botting (not patched you can do a ton of share)
  * Easy to use, Fast
  * Compatible Linux / Win / (didnt tested for macos)
  * Proxy Scrapper integrated
```

## Installation
```
  * pip install requests pystyle
```

##  Usage:
```
  * Video Tutorial : https:/discord.gg/069
  * python <ShareBot.py or ViewBot.py>
  * paste video url
  * choose amount
  * enter yes or no if you want to scrap proxie
  * enter proxy type you put in Proxies.txt
  * enter proxy timeout | choose 3 if you want a good timeout
  * enter thread | more thread = faster but make your computer slower | choose 100~1000
```

## Tricks
```js
  * Use on vps (Faster !)
  * Run 3 times one with http proxy type, one with socks4 proxy type and same for socks5
```

## Scammers
```js
  * yezzjoestar#0001   | 923211134901841982    | Selling tool for 20E
  * Biloo#8484         | 963482748914384957    | Skid + Veski
  * Uhky#0001          | 955883575604019310    | Skid + Veski
  * ΞZIR#0001          | 962708528118767646    | Skid + Veski
  * Xtro#0001          | 797801852833103912    | Skid + Selling tool for 20E (friend of yezzjoestar)
  * Luxs#0002          | 646941764032397313    | Skid + Selling tool for 20$
  * Krsxz#0001         | 954372342887378944    | Skid + Veski (Guild ID: 965193120700596244)
  * hz#3623            | 933330648373006406    | Skid + Veski (Guild ID: 960149739268112454)
  * 151k#6661          | 814508737745911878    | Skid & Selling
  * Lekkas#9751        | 938092182819176511    | Skid & Selling (Guild ID: 951470783077679104)
  * zrh#2000           | 840699051103617084    | Skid & Sellibng  (Guild ID: 940236490691182632)
  * HugooMig#0001      | 939910195570688060    | Skid & Selling tool for 5E
  * https://github.com/moxy-code/TikTok-Share-Bot
  * https://github.com/CrystalEU/ShareBot-Tiktok
  * https://github.com/zenty404/TikTok_Share_Bot
  * https://github.com/gsventu/Tiktok-Share-Bot
  * https://github.com/ladas2000/tiktok-sharebot | no Credit
  * https://github.com/CrystalEU/Viewbot-Tiktok
  * https://github.com/2wz/tiktok-shares-bot
  * https://github.com/floppa1337/Tiktok-Sharebot
  * https://github.com/dos-argenta/TikTokShareBot-SpiritOfStalker
  * https://github.com/drezhack/TikTok-Shares
  * https://github.com/KazamaOnGithub/TikTok_ShareBoost
  
  Thanks to github.com/b6m | github.com/00a1 for tracking these skids & scammers !
```

##  Credits:
 > [!]
 <br>Discord : https://discord.gg/069
